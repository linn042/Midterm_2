package com.example.midterm_2_lianna

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var userService: UserService
    private val users = mutableListOf<User>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize Retrofit service
        val retrofit = Retrofit.Builder()
            .baseUrl("https://randomuser.me/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        userService = retrofit.create(UserService::class.java)

        // Setup RecyclerView
        val layoutManager = LinearLayoutManager(this)
        binding.rvUsers.layoutManager = layoutManager

        val adapter = UserAdapter(users)
        binding.rvUsers.adapter = adapter

        // Load users
        loadUsers()
    }

    private fun loadUsers() {
        lifecycleScope.launch {
            try {
                val response = userService.getUsers(50)
                if (response.isSuccessful) {
                    val results = response.body()?.results
                    if (results != null) {
                        users.clear()
                        for (result in results) {
                            val user = User(
                                name = "${result.name.first} ${result.name.last}",
                                email = result.email,
                                nationality = result.nat
                            )
                            users.add(user)
                        }
                        binding.rvUsers.adapter?.notifyDataSetChanged()
                    }
                } else {
                    Log.e("MainActivity", "Failed to load users: ${response.code()}")
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Failed to load users", e)
            }
        }
    }
}
