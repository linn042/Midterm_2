package com.example.midterm_2_lianna

data class User(
    val name: String,
    val email: String,
)
