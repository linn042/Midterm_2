package com.example.midterm_2_lianna

interface UserService {

    @GET("api/")
    suspend fun getUsers(@Query("results") count: Int): Response<UserResponse>
}
